# TRELLO SIDEBAR

Unofficial Trello for Chrome App. As sidebar style (recommended).

# RESOURCES

- [Trello Icon – Max Masnick](http://goo.gl/AbJjX)
