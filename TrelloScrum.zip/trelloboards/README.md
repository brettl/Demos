# Boards for Trello

Trello Boards presents a list of all your active Trello Boards on the extension bar, saving you the trouble of creating
your own bookmarks to each new board created.

Track development: https://trello.com/board/trello-boards-chrome-extension/4f35cbaf2bacc8c844042895
